package com.igm.badhoc.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.igm.badhoc.R;
import com.igm.badhoc.model.MessageBadhoc;
import com.igm.badhoc.model.Tag;

import java.io.Serializable;
import java.util.List;

public class MessagesBadhocAdapter extends RecyclerView.Adapter<MessagesBadhocAdapter.MessageViewHolder> implements Serializable {

    private List<MessageBadhoc> messageBadhocs;
    private String conversationId;

    public MessagesBadhocAdapter(String conversationId) {
        this.conversationId = conversationId;
    }

    public MessagesBadhocAdapter(List<MessageBadhoc> messageBadhocs, String conversationId) {
        this.messageBadhocs = messageBadhocs;
        this.conversationId = conversationId;
    }

    public void addMessage(MessageBadhoc message) {
        this.messageBadhocs.add(message);
        notifyItemInserted(messageBadhocs.size() - 1);
    }

    @Override
    public int getItemCount() {
        return messageBadhocs.size();
    }

    public void setConversationId(String conversationId) {
        this.conversationId = conversationId;
    }

    @Override
    public int getItemViewType(int position) {
        return messageBadhocs.get(position).getDirection();
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View messageView = null;

        switch (viewType) {
            case MessageBadhoc.INCOMING_MESSAGE:
                messageView = LayoutInflater.from(viewGroup.getContext()).
                        inflate((R.layout.message_row_incoming), viewGroup, false);
                break;
            case MessageBadhoc.OUTGOING_MESSAGE:
                messageView = LayoutInflater.from(viewGroup.getContext()).
                        inflate((R.layout.message_row_outgoing), viewGroup, false);
                break;
        }

        return new MessageViewHolder(messageView);
    }

    @Override
    public void onBindViewHolder(final MessageViewHolder messageHolder, int position) {
        messageHolder.setMessage(messageBadhocs.get(position));
    }

    public void setMessageBadhocs(List<MessageBadhoc> messageBadhocs) {
        this.messageBadhocs = messageBadhocs;
    }

    public class MessageViewHolder extends RecyclerView.ViewHolder {
        final TextView txtMessage;
        final TextView deviceMessageName;
        MessageBadhoc message;

        MessageViewHolder(View view) {
            super(view);
            txtMessage = view.findViewById(R.id.txtMessage);
            deviceMessageName = view.findViewById(R.id.deviceMessageName);
        }

        void setMessage(MessageBadhoc message) {
            this.message = message;
            if (message.getDirection() == MessageBadhoc.INCOMING_MESSAGE &&
                    conversationId.equals(Tag.BROADCAST_CHAT.value)) {
                this.deviceMessageName.setText(message.getDeviceName());
            }
            this.txtMessage.setText(message.getText());
        }
    }
}
