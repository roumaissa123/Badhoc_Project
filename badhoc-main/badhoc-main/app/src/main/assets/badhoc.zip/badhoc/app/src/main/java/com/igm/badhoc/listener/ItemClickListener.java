package com.igm.badhoc.listener;

import android.view.View;

public interface ItemClickListener {
    void onItemClick(View view, int position);
}
